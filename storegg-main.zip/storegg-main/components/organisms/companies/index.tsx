import React from "react";

type Props = {};

export default function Companies({}: Props) {
  return (
    <section className="py-5">
      <div className="d-none d-lg-flex justify-content-center   mt-70 hero-logos">
        <img src="/svg/storegg-x-companies.svg" alt="StoreGG" />
      </div>
    </section>
  );
}
