import React from "react";

type Props = {};

function VerticalLine({}: Props) {
  return <div className="vertical-line me-lg-35 ms-lg-35 d-lg-block d-none" />;
}

export default VerticalLine;
